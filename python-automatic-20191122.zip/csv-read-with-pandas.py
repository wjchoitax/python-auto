import pandas as pd

df = pd.read_csv('test.csv')

new_df = df.loc[df['매출'] >= 7500000]

new_df.to_csv('new.csv', index=False)
