from selenium import webdriver
from selenium.webdriver.support.ui import Select
import time

driver = webdriver.Chrome('./chromedriver')
driver.get('http://www.opinet.co.kr/searRgSelect.do')
driver.get('http://www.opinet.co.kr/searRgSelect.do')
driver.implicitly_wait(3)
time.sleep(2)

sido_select = Select(driver.find_element_by_id('SIDO_NM0'))
sido_select.select_by_value('부산광역시')
driver.implicitly_wait(2)
time.sleep(2)

sigungu_select = Select(driver.find_element_by_id('SIGUNGU_NM0'))
sigungu_select.select_by_value('해운대구')
driver.implicitly_wait(3)

time.sleep(5)

driver.close()
