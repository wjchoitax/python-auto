movies = {
    '박찬욱': '올드보이',
    '홍상수': '그때는 맞고 지금은 다르다',
    '곽경택': '친구'
}

for i in range(10):
    print('반복', i)

for index, key in enumerate(movies):
    print(key, index)

# del movies['홍상수']
#
# for key, value in movies.items():
#     print(key, value)
#
# print(movies.get('홍상수'))

# print(movies['홍상수'])
#
# movies['박찬욱'] = '아가씨'
#
# movies['강우석'] = '공공의적'
#
# print(movies)
#
