from selenium import webdriver
from bs4 import BeautifulSoup
import time

options = webdriver.ChromeOptions()
options.add_argument('headless')
options.add_argument('window-size=1920x1080')

driver = webdriver.Chrome('./chromedriver', options=options)

driver.get('https://www.melon.com/chart/index.htm')
driver.implicitly_wait(3)
driver.get_screenshot_as_file('melon-capture.png')
src = driver.page_source
driver.close()

time.sleep(3)

soup = BeautifulSoup(src, 'html.parser')
print(soup)

