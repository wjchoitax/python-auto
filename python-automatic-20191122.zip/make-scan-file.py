# 실습을 위한 스캔파일을 생성
import os

os.makedirs('c:/scandata', exist_ok=True)

with open('c:/scandata/file_scan_2019-11-18-0947.pdf', 'w') as file:
    print('file generated..')


print('ok')