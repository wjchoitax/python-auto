import requests

BASE_URL = 'https://openapi.naver.com/v1/papago/n2mt'

text = '''
every year, billions of dollars' worth of art passes through international auction houses, while leading museums each hold tens of thousands -- even hundreds of thousands -- of artworks in their collections. But precious few ever achieve the fame required to truly be considered household names.
As "famous" is a subjective term, CNN Style turned to Google to see which paintings topped search results worldwide over the past five years.
We compared dozens of popular masterpieces -- from classics such as "Mona Lisa," "The Great Wave off Kanagawa" and the "Salavator Mundi," to more modern works like "Nighthawks" and even the "Dogs Playing Poker" series.
'''

PAYLOAD = {
    'source': 'en',
    'target': 'ko',
    'text': text
}
HEADERS = {
    'X-Naver-Client-Id': 'H8ePWN2jh7Bu_BTvQZiM',
    'X-Naver-Client-Secret': 'pePJcG_C4E'
}

res = requests.post(BASE_URL, data=PAYLOAD, headers=HEADERS)
print(res.json())