score = None

if score:
    print('합격')
else:
    print('불합격')

