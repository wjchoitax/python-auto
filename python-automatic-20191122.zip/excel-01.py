import openpyxl

# 워크북을 만든다.
wb = openpyxl.Workbook()
# ws = wb.worksheets['sheet1']
ws = wb.active

ws['A1'] = 'Hello world'

wb.save('first-excel.xlsx')