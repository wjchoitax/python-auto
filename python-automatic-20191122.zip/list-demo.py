favorite_colors = ['red', 'brown', 'blue', 'white']

# for color in favorite_colors:
#     print(color.upper())
#
# favorite_colors.sort()

favorite_colors_tuple = 'red', 'brown', 'blue', 'white'
print(favorite_colors_tuple[2])

print(favorite_colors)

a, b, c, d = favorite_colors

print(b)

