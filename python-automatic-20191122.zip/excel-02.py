import openpyxl
import datetime

wb = openpyxl.load_workbook('first-excel.xlsx')
ws = wb.active

ws['B3'] = datetime.datetime.now()

wb.save('second-excel.xlsx')