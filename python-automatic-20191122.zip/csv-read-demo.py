import csv
import pprint

result_list = []

with open('test.csv', encoding='utf-8') as file:
    reader = csv.reader(file)
    result_list = list(reader)

new_list = []
for row in result_list[1:]:
    if int(row[2]) >= 7500000:
        new_list.append(row)

pprint.pprint(new_list)