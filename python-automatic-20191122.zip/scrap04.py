import requests

headers = {
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.108 Safari/537.36'
}

res = requests.get(
    'https://www.coupang.com/np/campaigns/82/components/194176', headers=headers)
print(res)
