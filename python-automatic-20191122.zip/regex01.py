import re

image_pattern = re.compile(r'^.*\.(jpg|png|jpeg|gif)$') # raw string

if image_pattern.match('abc.pngh'):
    print('매칭됬음')
else:
    print('not match')