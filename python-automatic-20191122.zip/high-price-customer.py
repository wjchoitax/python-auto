import openpyxl

def main():
    wb = openpyxl.load_workbook('고액수강생.xlsx', read_only=True)
    ws = wb['Sheet1']

    high_price_members = []
    for row_index in range(2, ws.max_row + 1):
        if ws.cell(row_index, 2).value > 900000:
            high_price_members.append(ws.cell(row_index, 4).value)

    send_email(high_price_members)
    print(high_price_members)


main()