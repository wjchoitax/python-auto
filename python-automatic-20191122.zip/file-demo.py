# 파일 읽기 - 텍스트 파일 / 바이너리 파일

file = open('./test.txt', encoding='utf-8')
line_list = file.readlines()

new_list = []
for line in line_list:
    new_list.append(line.strip())

# print(new_list)
file.close()

# 디렉토리의 파일 목록 읽어오기
import os
file_list = os.listdir('c:/')
print(file_list)

for file_name in file_list:
    if file_name[-4:] == '.txt':
        print(file_name)

os.makedirs('c:/test', exist_ok=True)
print('make dir ok..')
