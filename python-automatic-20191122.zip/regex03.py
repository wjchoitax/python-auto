import re

pattern = re.compile(r'''
    [,.]?      # 처음에 ,. 올수있음
    \s*        # 공백이 올수있음
    [.,]*      # ,.
    \s+        # 반드시 공백하나이상
    ''', re.VERBOSE)

my_str = 'hello hi, good. ok .. thanks'

# splitted_list = my_str.split(re.compile(r'[,.]?\s+[.,]*\s+'))

splitted_list = pattern.split(my_str)

print(splitted_list)


H8ePWN2jh7Bu_BTvQZiM
pePJcG_C4E