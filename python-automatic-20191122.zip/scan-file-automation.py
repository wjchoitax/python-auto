import os
import shutil
import glob

SCAN_SRC_DIR = 'c:/scandata'
SCAN_DST_DIR = 'c:/organized'

def make_dir_with_file_name(file_name):
    # 연도 디렉토리 만들기
    os.makedirs(SCAN_DST_DIR + '/'
                + file_name.split('_')[-1][:4], exist_ok=True)
    # 월 디렉토리 만들기
    os.makedirs(SCAN_DST_DIR + '/'
                + file_name.split('_')[-1][:4] + '/'
                + file_name.split('_')[-1][5:7], exist_ok=True)
    # 일 디렉토리 만들기
    os.makedirs(SCAN_DST_DIR + '/'
                + file_name.split('_')[-1][:4] + '/'
                + file_name.split('_')[-1][5:7] + '/'
                + file_name.split('_')[-1][8:10], exist_ok=True)


def copy_file_to_organized(file_name):
    shutil.copy(SCAN_SRC_DIR + '/' + file_name,
                SCAN_DST_DIR + '/'
                + file_name.split('_')[-1][:4] + '/'
                + file_name.split('_')[-1][5:7] + '/'
                + file_name.split('_')[-1][8:10])

def delete_scandata_dir():
    # 스캔 디렉토리의 모든 파일 삭제..
    pass # TODO

def main():
    # c:/scandata 디렉토리의 파일 목록을 읽어온다.
    #file_list = os.listdir(SCAN_SRC_DIR)
    file_list = glob.glob1(SCAN_SRC_DIR, '*.pdf')

    os.makedirs(SCAN_DST_DIR, exist_ok=True)

    for file_name in file_list:
        make_dir_with_file_name(file_name)
        # 파일 복사하기
        copy_file_to_organized(file_name)
        print('copy ok.. ' + SCAN_SRC_DIR + '/' + file_name)

    delete_scandata_dir()

main()