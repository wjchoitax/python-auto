def add_two_number(num_one=0, num_two=0):
    return num_one + num_two


result = add_two_number(num_two=3)

print(result, end='...')

a = 'hello'

a.upper()

type(a)

a = 'hello'