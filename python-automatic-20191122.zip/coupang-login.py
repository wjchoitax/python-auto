from selenium import webdriver
import time

driver = webdriver.Chrome('./chromedriver')
driver.get('https://login.coupang.com/login/login.pang')
driver.implicitly_wait(3)

# 아이디 입력
driver.find_element_by_id('login-email-input')\
    .send_keys('soongon@gmail.com')
time.sleep(1)
# 패스워드 입력
driver.find_element_by_id('login-password-input')\
    .send_keys('abcdedf')
time.sleep(1)
# 로그인 버튼 클릭
driver.find_element_by_xpath('/html/body/div[1]/div/div/form/div[5]/button')\
    .click()

driver.implicitly_wait(3)

time.sleep(3)

driver.close()