import requests
import pandas as pd
import pprint

BASE_URL = 'https://openapi.naver.com/v1/search/news.json'
PARAMS = {
        'query': '겨울왕국2',
        'display': 100
}
HEADERS = {
    'X-Naver-Client-Id': 'H8ePWN2jh7Bu_BTvQZiM',
    'X-Naver-Client-Secret': 'pePJcG_C4E'
}

def save_to_excel(list, file_name):
    df = pd.DataFrame(list)
    df.to_excel(file_name, index=False)

def main():
    res = requests.get(BASE_URL, params=PARAMS, headers=HEADERS)

    news_list = []
    for item in res.json().get('items'):
        try:
            news_list.append([
                item.get('title'),
                item.get('originallink'),
                item.get('link'),
                item.get('description'),
                item['pubDate']
            ])
        except:
            news_list.append(['','','','','',''])

    save_to_excel(news_list, 'news_list.xlsx')
    print('job completed..')


main()