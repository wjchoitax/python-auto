import requests
from bs4 import BeautifulSoup

res = requests.get('http://www.11st.co.kr/html/bestSellerMain.html')
res.encoding = 'euc-kr'

soup = BeautifulSoup(res.text, 'html.parser')
# print(soup)

the_tag = soup.select_one('#bestPrdList > ul > li:nth-child(1) > div.product_conts > div.pup_info > div.pup_title > a')
print(the_tag.text)





#emergencyPrd > div > ul > li



