import requests
from bs4 import BeautifulSoup

res = requests.get('https://finance.naver.com/')

# print(res.text)

soup = BeautifulSoup(res.text, 'html.parser')

# print(soup)

the_tag = soup.select_one('#content > div.article2 > div.section1 > div.group1 > table > tbody > tr.up.bold > td:nth-child(2)')

print(the_tag.text)