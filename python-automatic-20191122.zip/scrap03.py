import requests
from bs4 import BeautifulSoup
import pandas as pd
import pprint

res = requests.get('http://deal.11st.co.kr/html/nc/deal/main.html')
res.encoding = 'euc-kr'

soup = BeautifulSoup(res.text, 'html.parser')

product_list = []
for li in soup.select('#emergencyPrd > div > ul > li'):
    product_list.append([
        li.select_one('div > a > div.prd_info > p > span.fs_16').text,
        li.select_one('div > a > div.prd_info > div > span.price_detail > strong').text
    ])

pprint.pprint(product_list)

df = pd.DataFrame(product_list, columns=['상품명', '가격'])
df.to_excel('11st.xlsx', index=False)
